package com.vocalstudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.util.AttributeSet
import android.view.View
import java.io.BufferedInputStream
import kotlin.math.abs
import kotlin.math.max

class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF17191E.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5EC8FF.toInt()
        strokeWidth = 2f
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF252932.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private var peaks = FloatArray(0)

    fun setAudioUri(uri: Uri) {
        // Lightweight PCM-WAV visualization for the first Android milestone.
        peaks = try {
            context.contentResolver.openInputStream(uri)?.use { raw ->
                val input = BufferedInputStream(raw)
                val header = ByteArray(44)
                if (input.read(header) < 44) return@use FloatArray(0)
                val data = input.readBytes()
                val count = 900
                val result = FloatArray(count)
                val bytesPerBucket = max(1, data.size / count)
                for (i in 0 until count) {
                    val start = i * bytesPerBucket
                    val end = minOf(data.size, start + bytesPerBucket)
                    var peak = 0f
                    var j = start
                    while (j + 1 < end) {
                        val lo = data[j].toInt() and 0xFF
                        val hi = data[j + 1].toInt()
                        val sample = (lo or (hi shl 8)).toShort().toInt()
                        peak = max(peak, abs(sample / 32768f))
                        j += 2
                    }
                    result[i] = peak
                }
                result
            } ?: FloatArray(0)
        } catch (_: Exception) {
            FloatArray(0)
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = RectF(8f, 8f, width - 8f, height - 8f)
        canvas.drawRoundRect(r, 14f, 14f, bg)
        canvas.drawRoundRect(r, 14f, 14f, border)

        if (peaks.isEmpty()) return

        val center = height / 2f
        val scaleX = (width - 20f) / peaks.size
        for (i in peaks.indices) {
            val x = 10f + i * scaleX
            val h = peaks[i] * (height * 0.42f)
            canvas.drawLine(x, center - h, x, center + h, line)
        }
    }
}
