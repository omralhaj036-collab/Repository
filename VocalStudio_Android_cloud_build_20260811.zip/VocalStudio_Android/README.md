# Vocal Studio Android — v0.1

Android-first foundation for the Vocal Studio project.

## Why this architecture?

Android high-performance audio is handled natively through AAudio.
The UI is Kotlin/Android, while the real-time audio path is C++.

Android's official NDK documentation recommends Oboe or AAudio for
high-performance audio applications such as DAWs and audio effects.
This first milestone uses AAudio directly to keep the foundation small.

## Current features

- Android app
- Landscape tablet-oriented UI
- Native C++ audio engine
- PCM 16-bit WAV loading
- Waveform preview
- Native low-latency AAudio playback
- Dry/enhanced toggle
- Initial deterministic polish stage

## Important limitation

The `AI VOCAL ENHANCE` button is NOT yet a neural denoiser.
It is intentionally a placeholder for the real AI restoration engine.

Next milestones:

1. Robust WAV/FLAC/MP3 decoding
2. Real-time safe ring buffer
3. Audio analysis engine
4. AI denoise model
5. De-reverb
6. De-click / de-plosive
7. Vocal-aware EQ
8. De-esser
9. Adaptive compression
10. True-peak / LUFS analysis
11. Non-destructive processing graph
12. Offline high-quality render
13. Export WAV/FLAC
14. Presets and project files

## Build

Open this directory in Android Studio.

Install/enable:
- Android SDK
- Android SDK Platform 36
- Android NDK 27.2.12479018
- CMake 3.22.1

Then Sync Project and Run on an Android tablet/phone.

The project uses Gradle externalNativeBuild with CMake.
