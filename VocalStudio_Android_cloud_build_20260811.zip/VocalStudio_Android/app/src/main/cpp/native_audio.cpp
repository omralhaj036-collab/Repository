#include <jni.h>
#include <aaudio/AAudio.h>
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "VocalStudio", __VA_ARGS__)

struct AudioState {
    std::vector<float> mono;
    int sampleRate = 48000;
    size_t cursor = 0;
    AAudioStream* stream = nullptr;
    bool enhanced = false;
    float level = 0.0f;
};

static AudioState g;

static uint32_t u32(const unsigned char* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) |
           (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

static uint16_t u16(const unsigned char* p) {
    return uint16_t(p[0]) | (uint16_t(p[1]) << 8);
}

static bool loadPcm16Wav(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;

    std::vector<unsigned char> bytes(
        (std::istreambuf_iterator<char>(in)),
        std::istreambuf_iterator<char>());

    if (bytes.size() < 44 ||
        std::string(reinterpret_cast<char*>(bytes.data()), 4) != "RIFF" ||
        std::string(reinterpret_cast<char*>(bytes.data() + 8), 4) != "WAVE") {
        return false;
    }

    uint16_t channels = 0, bits = 0;
    uint32_t rate = 0, dataSize = 0, dataOffset = 0;

    size_t p = 12;
    while (p + 8 <= bytes.size()) {
        const char* id = reinterpret_cast<const char*>(bytes.data() + p);
        const uint32_t size = u32(bytes.data() + p + 4);
        const size_t body = p + 8;
        if (body + size > bytes.size()) break;

        if (std::string(id, 4) == "fmt " && size >= 16) {
            const uint16_t format = u16(bytes.data() + body);
            channels = u16(bytes.data() + body + 2);
            rate = u32(bytes.data() + body + 4);
            bits = u16(bytes.data() + body + 14);
            if (format != 1) return false; // PCM only for v0.1
        } else if (std::string(id, 4) == "data") {
            dataOffset = static_cast<uint32_t>(body);
            dataSize = size;
            break;
        }

        p = body + size + (size & 1u);
    }

    if (channels == 0 || rate == 0 || bits != 16 || dataOffset == 0) return false;

    const size_t frames = dataSize / (channels * sizeof(int16_t));
    g.mono.resize(frames);

    const unsigned char* d = bytes.data() + dataOffset;
    for (size_t f = 0; f < frames; ++f) {
        float sum = 0.0f;
        for (uint16_t ch = 0; ch < channels; ++ch) {
            const size_t off = (f * channels + ch) * 2;
            int16_t s = static_cast<int16_t>(uint16_t(d[off]) | (uint16_t(d[off + 1]) << 8));
            sum += static_cast<float>(s) / 32768.0f;
        }
        g.mono[f] = sum / static_cast<float>(channels);
    }

    g.sampleRate = static_cast<int>(rate);
    g.cursor = 0;
    return true;
}

// v0.1 deterministic vocal-polish stage.
// This is intentionally not presented as AI denoising yet.
static float processSample(float x) {
    if (!g.enhanced) return x;

    // Gentle soft-knee saturation/limiting.
    const float threshold = 0.72f;
    if (std::fabs(x) > threshold) {
        const float sign = x < 0 ? -1.0f : 1.0f;
        const float excess = std::fabs(x) - threshold;
        x = sign * (threshold + std::tanh(excess * 2.0f) * 0.22f);
    }

    return std::clamp(x, -0.98f, 0.98f);
}

static aaudio_data_callback_result_t audioCallback(
    AAudioStream*,
    void* userData,
    void* audioData,
    int32_t numFrames) {

    auto* out = static_cast<float*>(audioData);
    const size_t n = static_cast<size_t>(numFrames);

    float peak = 0.0f;

    for (size_t i = 0; i < n; ++i) {
        float x = 0.0f;
        if (g.cursor < g.mono.size()) {
            x = processSample(g.mono[g.cursor++]);
        } else {
            x = 0.0f;
        }

        peak = std::max(peak, std::fabs(x));

        // AAudio stream is requested as mono in this first milestone.
        out[i] = x;
    }

    g.level = std::max(peak, g.level * 0.94f);

    if (g.cursor >= g.mono.size())
        return AAUDIO_CALLBACK_RESULT_STOP;

    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vocalstudio_app_MainActivity_nativeLoadWav(
    JNIEnv* env, jobject, jstring path) {

    const char* utf = env->GetStringUTFChars(path, nullptr);
    const bool ok = loadPcm16Wav(utf);
    env->ReleaseStringUTFChars(path, utf);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vocalstudio_app_MainActivity_nativePlay(
    JNIEnv*, jobject) {

    if (g.mono.empty()) return JNI_FALSE;

    if (g.stream != nullptr) {
        AAudioStream_close(g.stream);
        g.stream = nullptr;
    }

    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK) return JNI_FALSE;

    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(builder, 1);
    AAudioStreamBuilder_setSampleRate(builder, g.sampleRate);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setDataCallback(builder, audioCallback, nullptr);

    aaudio_result_t result = AAudioStreamBuilder_openStream(builder, &g.stream);
    AAudioStreamBuilder_delete(builder);

    if (result != AAUDIO_OK) {
        g.stream = nullptr;
        LOGE("AAudio open failed: %s", AAudio_convertResultToText(result));
        return JNI_FALSE;
    }

    g.cursor = 0;
    result = AAudioStream_requestStart(g.stream);
    if (result != AAUDIO_OK) {
        AAudioStream_close(g.stream);
        g.stream = nullptr;
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vocalstudio_app_MainActivity_nativeStop(
    JNIEnv*, jobject) {

    if (g.stream != nullptr) {
        AAudioStream_requestStop(g.stream);
        AAudioStream_close(g.stream);
        g.stream = nullptr;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vocalstudio_app_MainActivity_nativeSetEnhanced(
    JNIEnv*, jobject, jboolean enabled) {
    g.enhanced = enabled;
    return JNI_TRUE;
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_vocalstudio_app_MainActivity_nativeGetLevelDb(
    JNIEnv*, jobject) {
    if (g.level < 0.000001f) return -100.0f;
    return 20.0f * std::log10(g.level);
}
