package com.vocalstudio.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.vocalstudio.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var currentUri: Uri? = null
    private var enhanced = false

    private external fun nativeLoadWav(path: String): Boolean
    private external fun nativePlay(): Boolean
    private external fun nativeStop()
    private external fun nativeSetEnhanced(enabled: Boolean): Boolean
    private external fun nativeGetLevelDb(): Float

    private val openFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult

            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Some providers do not support persistable permissions.
            }

            currentUri = uri
            binding.waveform.setAudioUri(uri)
            binding.status.text = "Selected: ${uri.lastPathSegment ?: "audio.wav"}"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }

        binding.openButton.setOnClickListener {
            openFile.launch(arrayOf("audio/wav", "audio/x-wav", "audio/*"))
        }

        binding.playButton.setOnClickListener {
            val uri = currentUri
            if (uri == null) {
                toast("Open a WAV vocal recording first.")
                return@setOnClickListener
            }

            val localPath = UriCache.copyToCache(this, uri)
            if (localPath == null || !nativeLoadWav(localPath)) {
                toast("This first build expects a readable PCM WAV file.")
                return@setOnClickListener
            }

            nativePlay()
            binding.status.text = if (enhanced)
                "Playing — enhancement chain ON"
            else
                "Playing — dry"
        }

        binding.stopButton.setOnClickListener {
            nativeStop()
            binding.status.text = "Stopped"
        }

        binding.enhanceButton.setOnClickListener {
            enhanced = !enhanced
            nativeSetEnhanced(enhanced)
            binding.enhanceButton.text =
                if (enhanced) "AI ENHANCE: ON" else "AI VOCAL ENHANCE"
            binding.status.text =
                if (enhanced) "Enhancement chain enabled"
                else "Dry monitoring"
        }
    }

    override fun onDestroy() {
        nativeStop()
        super.onDestroy()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object {
        init {
            System.loadLibrary("vocalstudio")
        }
    }
}
