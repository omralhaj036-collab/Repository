# بناء Vocal Studio APK بدون كمبيوتر

هذه الحزمة مجهزة للبناء السحابي عبر GitHub Actions.

1. أنشئ Repository جديدًا في GitHub.
2. ارفع محتويات مجلد `VocalStudio_Android`.
3. افتح تبويب `Actions`.
4. اختر `Build Vocal Studio APK`.
5. اضغط `Run workflow`.
6. بعد نجاح العملية افتح `Artifacts`.
7. حمّل `VocalStudio-debug-apk`.
8. فك الضغط وستجد `app-debug.apk`.
9. انقل APK إلى جهاز Android وثبّته.

إذا ظهر أي خطأ في البناء، أرسل نص الخطأ أو صورة الشاشة لي، وسأتعامل معه تحديدًا.
