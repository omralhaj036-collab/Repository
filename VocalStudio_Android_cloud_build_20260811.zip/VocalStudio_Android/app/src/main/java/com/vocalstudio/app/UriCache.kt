package com.vocalstudio.app

import android.content.Context
import android.net.Uri
import java.io.File

object UriCache {
    fun copyToCache(context: Context, uri: Uri): String? {
        return try {
            val target = File(context.cacheDir, "current_input.wav")
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            target.absolutePath
        } catch (_: Exception) {
            null
        }
    }
}
